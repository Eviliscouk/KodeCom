import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-subcontractor-start',
  templateUrl: './subcontractor-start.component.html',
  styleUrls: ['./subcontractor-start.component.css']
})
export class SubcontractorStartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
