

export class ContractorName {
  public c_ID: number;
  public displayName: string;

  constructor(c_ID: number, displayName: string) {
    this.c_ID = c_ID;
    this.displayName =displayName;
  }
}