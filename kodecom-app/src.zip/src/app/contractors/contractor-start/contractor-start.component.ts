import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contractor-start',
  templateUrl: './contractor-start.component.html',
  styleUrls: ['./contractor-start.component.css']
})
export class ContractorStartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
