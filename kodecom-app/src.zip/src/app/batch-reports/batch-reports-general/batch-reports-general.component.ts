import { Component, OnInit } from '@angular/core';

declare var $:any;

@Component({
  selector: 'app-batch-reports-general',
  templateUrl: './batch-reports-general.component.html',
  styleUrls: ['./batch-reports-general.component.css']
})
export class BatchReportsGeneralComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  showModal()
  {
    $('#myModalText').text("Processing Request");
    $("#myModal").modal('show');
  }

  updateModalText(text :string)
  {
     $('#myModalText').text(text);
  }

  closeModal()
  {
    $("#myModal").modal('hide');
  }

}
