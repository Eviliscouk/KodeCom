export class Batch {
  public id: number;
  public fileName: string;
  public status: string;
  public dated: string;
  public userName: string;
  constructor() {
    
  }
}