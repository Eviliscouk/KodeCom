import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-batch-reports',
  templateUrl: './batch-reports.component.html',
  styleUrls: ['./batch-reports.component.css']
})
export class BatchReportsComponent implements OnInit {
  constructor() { }

  ngOnInit() {

  }
}
