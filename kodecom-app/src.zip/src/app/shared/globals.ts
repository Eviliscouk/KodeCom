//export var serviceRoot: string = 'http://www.paygenieonline.co.uk'; 
export var serviceRoot: string = 'https://kode-com-kerrjp.c9users.io';